Documentation for Waveform GUI
Inital Setup
------------
-Download any of the recent version of Python (make sure you choose to install pip with it)
-(Recommended) Download Visual Studio Code as a text editor for code with a convenient terminal menu
-Once you have the file with all the code (gui2.py), put it in a folder in some accessible place such as 
 your desktop, and open that folder through VS Code

Imports
-------
-PySimpleGui is the library you need to import in order to easily 
 develop the layout for the GUI.
	-Installation: Enter "pip install pysimplegui" (or "py -m pip install pysimplegui") in the command prompt
-pySerial is the library you need for serial communication between python and a microcontroller
 through COM ports.
	-Installation: Enter "pip install pyserial" (or "py -m pip install pyserial") in the command prompt

Code Functionality
------------------
-The first section of the program sets up all the layout for the GUI that we need
	-The GUI is set so that clicking submit will process all the info and try to send it serially
	-The GUI will only close if the program ends or the exit button is clicked
	-Pressing submit will allow you to continually click submit with whatever values you would like
-The methods "generateInfo" and "generateInfo2" pass in the values from all the inputs on the GUI,
 and use those values to return a dictionary of information that is more accessible and understandable
-Once the data is generated, "assertRanges" and "assertRanges2" will parse through all the data
 and make sure the inputted data was in the accepted ranges
	-If any of the data was inputted incorrectly, the error will be caught and the program will end

Running the Program
-------------------
-Once in VS Code in the folder where the Python file is located, click on the "Terminal" tab
 at the top of the screen and open a new terminal
-In the new terminal, make sure that the destination is the correct folder and it is using Powershell
	-If the destination is incorrect for some reason, use the commands "cd .." to move back a folder, 
	 and "cd Desktop" to move forward to your Desktop for example
-Once in the correct location, enter the command "python gui2.py" (or "py gui2.py" if the previous doesn't work)
	-You should see a drop down with two different programming options --> select one and press submit
-SINGLE DEVICE PROGRAMMING:
	-First Stage must be completely filled out
	-If an option for any of the other stages is selected, all the values for it must be filled out
	-Row and Column must be filled out (1-8 for both)
	-Number of repetitions defaults to 1, but accepted range is 1-125
	-Accepted range for all the Time/Blank Period fields is 1-125
	-Accepted range for Voltage fields is -2.5V to 2.5V, but must be left as 3.3V for Forming
-SINGLE COLUMN PROGRAMMING:
	-Every single field must be filled out
	-Time/Blank Period ranges 1-125
	-Voltage ranges -2.5V to 2.5V
	-Row Bit data must be 0 or 1, and from left to right is Rows [1,2,...,8]
	-Column ranges 1-8
-To close the GUI, hit the X in the top right